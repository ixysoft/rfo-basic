#!/bin/bash

unalias -a

cd x-quickapk-src

gbc3 -a -p && gba3

if [ $? = 0 ]; then

  mv -f x-quickapk-src.gambas ../x-quickapk
  chmod 755 ../x-quickapk
  echo x-quickapk successfully compiled.
  echo Type "./x-quickapk to run it." 

else 
  
  echo "Build failed!"
  
fi
