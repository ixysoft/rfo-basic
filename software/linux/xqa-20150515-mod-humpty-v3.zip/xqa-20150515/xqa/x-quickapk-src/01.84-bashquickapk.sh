#!/bin/bash

unalias -a
source ./x-quickapk.project

# When sourced, we remove sensible datas
# Don't delete file, we could need it in case of DEBUG="true"

grep -v ^ALIASPASS= x-quickapk.project > x-quickapk.project.tmp
mv x-quickapk.project.tmp x-quickapk.project

grep -v ^STOREPASS= x-quickapk.project > x-quickapk.project.tmp
mv x-quickapk.project.tmp x-quickapk.project

# Building function

BuildAPK() {
  
  Err_Report() {
    
    echo "Error on line $1"

  }
   
  trap 'Err_Report $LINENO' ERR
      
  PATH=$PATH:$JAVAJDKBIN:$TOOLSBIN
  
  # Log error
  echo `basename $BASICAPK`
    
  # Decompile Basic! APK
  
  java -jar $TOOLSBIN/apktool.jar d -f -o $WORKINGDIR -p /tmp $BASICAPK

  # Remove not alphanumeric chars for internal use

  INTAPPNAME=`echo $APPNAME | sed -e 's/[^A-Za-z0-9]//g'`
  APP_PATH=$INTAPPNAME

  # Java does not allow starting digit in resource name

  if `echo $INTAPPNAME | head -c1 | grep -q [0-9]`; then INTAPPNAME='_'$INTAPPNAME; fi

  cd $WORKINGDIR

  # Modifications to strings.xml 

  MY_PROGRAM=`basename $MAINBAS`

  cd res/values

  cat strings.xml | sed -e s/'app_name">BASIC!'/'app_name">'"$APPNAME"/ > strings.xml.tmp
  mv strings.xml.tmp strings.xml

  cat strings.xml | sed -e s/'app_path">rfo-basic'/'app_path">'"$APP_PATH"/ > strings.xml.tmp
  mv strings.xml.tmp strings.xml

  cat strings.xml | sed -e s/'name="my_program">my_program.bas'/'name="my_program">'"$MY_PROGRAM"/ > strings.xml.tmp
  mv strings.xml.tmp strings.xml

  cat strings.xml | sed -e s/'BASIC! Program Output'/"$APPNAME"/ > strings.xml.tmp
  mv strings.xml.tmp strings.xml

  cat strings.xml | sed -e s/'BASIC! Text Input'/"$APPNAME"' Text Input'/ > strings.xml.tmp
  mv strings.xml.tmp strings.xml

  cat strings.xml | sed -e s/'BASIC! Select'/"$APPNAME"' Select'/ > strings.xml.tmp
  mv strings.xml.tmp strings.xml
    
  if [ ! -z $MARKER ]; then

    cat strings.xml | sed s/'name="progress_marker">.'/'name="progress_marker">'"$MARKER"/ > strings.xml.tmp
    mv strings.xml.tmp strings.xml

  else

    cat strings.xml | sed s/'name="progress_marker">.'/'name="progress_marker">'/ > strings.xml.tmp
    mv strings.xml.tmp strings.xml

  fi
    
  # For the user which uses BASIC! version$() function

  STRINGVERSION=`cat strings.xml | grep name=\"version\" | cut -f2- -d\< | cut -f-1 -d\<`
  NEWSTRINGVERSION="string name=\"version\">"$VERSION

  cat strings.xml | sed -e s/"$STRINGVERSION"/"$NEWSTRINGVERSION"/ > strings.xml.tmp
  mv -f strings.xml.tmp strings.xml

  # END strings.xml 

  # Log error
  echo STRINGS.XML DONE 
    
  # Modifications to bools.xml  

  cat bools.xml | sed s/'name="is_apk">false'/'name="is_apk">true'/ > bools.xml.tmp
  mv bools.xml.tmp bools.xml

  # Start paranoia
  cat bools.xml | sed s/'name="apk_create_data_dir">false'/'name="apk_create_data_dir">true'/ > bools.xml.tmp
  mv bools.xml.tmp bools.xml

  cat bools.xml | sed s/'name="apk_create_database_dir">false'/'name="apk_create_database_dir">true'/ > bools.xml.tmp
  mv bools.xml.tmp bools.xml
  # End paranoia

  if [ ! -z $SPLASH ]; then
    
    if [ $SPLASH = "nosplash" ]; then
    
      cat bools.xml | sed s/'splash_display">true'/'splash_display">false'/ > bools.xml.tmp  
      mv bools.xml.tmp bools.xml
      
      # lighter final APK
      cp -f ../drawable/blank.png ../drawable/splash.png 
                
    fi
	  
  fi
  
  ### END bools.xml 
  
  # Log error
  echo BOOLS.XML DONE
  
  # Splash color

  cat colors.xml | sed s/'splash_color">#ffffffff'/'splash_color">'"$SPLASHBG"/ > colors.xml.tmp
  mv colors.xml.tmp colors.xml
  
  # Modifications to arrays.xml 

  # Startup message 

  if [ ! -z "$MESSAGE" ]; then

    cat arrays.xml | sed -e s/'Standby for initial file loading.'/"$MESSAGE"/ > arrays.xml.tmp
    mv arrays.xml.tmp arrays.xml
    
  else
    
    DELTHISLINE=`grep -n "Standby for initial file loading." arrays.xml | cut -f1 -d:`
    cat arrays.xml | sed "${DELTHISLINE}d" > arrays.xml.tmp
    mv arrays.xml.tmp arrays.xml
    
  fi  

  # Add files to load at startup

  if [ ! -z $FILESTOLOAD ]; then

    HEADLOFI=`grep -n '<array name="load_file_names"' arrays.xml | cut -f1 -d:`
    let HEADLOFI=$HEADLOFI-1
    
    head -$HEADLOFI arrays.xml > arrays.xml.tmp

    echo '<array name="load_file_names">' >> arrays.xml.tmp
      
    echo -e $FILESTOLOAD | while read FILE; do 
      
    [[ "$FILE" != "" ]] &&  echo '<item>'"$FILE"'</item>' >> arrays.xml.tmp
      
    done
  
    echo '</array>' >> arrays.xml.tmp
    echo '</resources>' >> arrays.xml.tmp
  
    mv -f arrays.xml.tmp arrays.xml
    
  fi  

  # END arrays.xml 
  
  # Log error
  echo ARRAYS.XML DONE
  
  # Copy splash picture, if any

  if [ ! -z "$SPLASHPICTURE" ]; then cp -f "$SPLASHPICTURE" ../drawable/splash.png; fi
  
  # Edit settings.xml
  
  cd $WORKINGDIR/res/xml

  # App console is white text on black screen, true or false
      
  if (echo $OPTIONS | grep blackconsole); then
      
    LINE=`grep -n  'android:summary="Select Color Scheme"' settings.xml | cut -f1 -d:`
    cat settings.xml | sed "$LINE s/BW/WB/" > settings.xml.tmp
    mv -f settings.xml.tmp settings.xml

  fi 
  
  # Remove console menu, true or false
    
  if (echo $OPTIONS | grep consolemenu); then
  
    LINE=`grep -n 'android:summary="Display Console Menu"' settings.xml | cut -f1 -d:`
    cat settings.xml | sed "$LINE s/true/false/" > settings.xml.tmp
    mv -f settings.xml.tmp settings.xml
    
  fi
   
  # Remove lines from console (always!)

  LINE=`grep -n  'android:summary="Use Lined Console"' settings.xml | cut -f1 -d:`
  cat settings.xml | sed "$LINE s/true/false/" > settings.xml.tmp
  mv -f settings.xml.tmp settings.xml
    
  # End settings.xml
  
  # Log error
  echo SETTINGS.XML DONE
    
  # Create and copy application ICONs

  cd $PROJECTDIR

  IMAGE="icon.png"

  SIZE=`identify icon.png | cut -f3 -d' '`

  cp -f icon.png $SIZE-icon.png

  for NEWSIZE in 36x36 48x48 72x72; do

    [[ $SIZE == $NEWSIZE ]] && continue
    convert $IMAGE -resize $NEWSIZE $NEWSIZE-icon.png

  done  

  mv -f 36x36-icon.png $WORKINGDIR/res/drawable-ldpi/icon.png
  mv -f 48x48-icon.png $WORKINGDIR/res/drawable-mdpi/icon.png
  mv -f 72x72-icon.png $WORKINGDIR/res/drawable-hdpi/icon.png

  rm -f $SIZE-icon.png
  
  # Log error
  echo ICONS DONE
    
  # Create App tree in assets

  cd $WORKINGDIR

  rm -fr assets/rfo-basic

  mkdir assets/$APP_PATH
  mkdir assets/$APP_PATH/data
  mkdir assets/$APP_PATH/databases
  mkdir assets/$APP_PATH/source

  # Copy program source files 

  [[ -f $MAINBAS ]] && cp -f $MAINBAS assets/$APP_PATH/source/ 

  for BASICFILE in $PROJECTDIR/source/*; do
    
    if [ $BASICFILE != $MAINBAS ]; then cp -f $BASICFILE assets/$APP_PATH/source/; fi
    
  done  

  # Adding files and databases used by App

  cp -f $PROJECTDIR/data/*  assets/$APP_PATH/data/ &>/dev/null
  cp -f $PROJECTDIR/databases/*  assets/$APP_PATH/databases/ &>/dev/null

  # Log error
  echo ASSETS DONE
  
  # Setting program version

  NEWVCODE=`echo ${VERSION}0000 | tr -d "." | head -c4`
  NEWVNAME=$VERSION

  count=0
  true > AndroidManifest.xml.tmp

  cat AndroidManifest.xml | while read LINE; do 
    
    let count=$count+1
    
    if [ $count = 2 ]; then
    
      echo '<manifest xmlns:android="http://schemas.android.com/apk/res/android"' >> AndroidManifest.xml.tmp
      echo package=\"com.bintray_rfo_basic.$INTAPPNAME\" >> AndroidManifest.xml.tmp
      
      if (echo $OPTIONS | grep externalstorage); then
  
        echo android:installLocation=\"auto\" >> AndroidManifest.xml.tmp
      
      fi  
      
      echo android:versionName=\"$NEWVNAME\" >> AndroidManifest.xml.tmp
      echo android:versionCode=\"$NEWVCODE\"\> >> AndroidManifest.xml.tmp
	  
    else
    
      echo "$LINE" >> AndroidManifest.xml.tmp
    
    fi
      
  done

  mv -f AndroidManifest.xml.tmp AndroidManifest.xml

  # Set permissions

  if [ ! -z $PERMISSIONS ]; then
    
  echo -e $PERMISSIONS | while read DISABLE; do 
      
      if [ -z $DISABLE ]; then continue; fi
      
      grep -v "$DISABLE" AndroidManifest.xml > AndroidManifest.xml.tmp
      mv -f AndroidManifest.xml.tmp AndroidManifest.xml
	
  done
    
  fi  

  # Log error
  echo PERMISSIONS DONE
    
  # App starts at device boot, true or false
  
  if (echo $OPTIONS | grep deviceboot); then  
    
    LINE=`grep -n 'receiver android:enabled="false"' AndroidManifest.xml | cut -f1 -d:`
    cat AndroidManifest.xml | sed  "$LINE s/false/true/" > AndroidManifest.xml.tmp
    mv -f AndroidManifest.xml.tmp AndroidManifest.xml

  fi   

  # Unregister .bas file extension

  EXTBAS=`grep -n "android:pathPattern=" AndroidManifest.xml | cut -f1 -d:`

  let STARTDEL=$EXTBAS-5
  let ENDDEL=$EXTBAS+2

  cat AndroidManifest.xml | sed "${STARTDEL},${ENDDEL}d" > AndroidManifest.xml.tmp
  mv -f AndroidManifest.xml.tmp AndroidManifest.xml

  # Unregister launcher shortcut

  LAUSHO=`grep -n android:targetActivity=\"LauncherShortcuts\" AndroidManifest.xml | cut -f1 -d:`

  STARTDEL=$LAUSHO
  let ENDDEL=$LAUSHO+5

  cat AndroidManifest.xml | sed "${STARTDEL},${ENDDEL}d" > AndroidManifest.xml.tmp
  mv -f AndroidManifest.xml.tmp AndroidManifest.xml

  # Log error
  echo LAUNCHERSHORTCUTS DONE
    
  # Update project paths

  cd $WORKINGDIR/smali/com/rfo/basic/

  for SMALIFILE in *; do

    cat $SMALIFILE | sed -e s/'rfo\/basic'/'bintray_rfo_basic\/'"$APP_PATH"/g > $SMALIFILE.tmp
    mv -f $SMALIFILE.tmp $SMALIFILE
    
  done

    for file in *; do

    cat $SMALIFILE | sed -e s/'rfo\.basic'/'bintray_rfo_basic\.'"$APP_PATH"/g > $SMALIFILE.tmp
    mv -f $SMALIFILE.tmp $SMALIFILE
    
  done

  cd $WORKINGDIR
  mv smali/com/rfo/basic smali/com/rfo/$APP_PATH
  mv smali/com/rfo smali/com/bintray_rfo_basic

  # End update project path
  
  # Log error
  echo UPDATE PATHS DONE
    
  # Recompile modified APK and name it quick.apk

  cd $WORKINGDIR/..

  java -jar $TOOLSBIN/apktool.jar b -f -o quick.apk -p /tmp/apktool_tmp Basic

  # Sign quick.apk and name it quick-signed.apk
  
  jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore $KEYSTORE -storepass $STOREPASS \
  -keypass $ALIASPASS -signedjar quick-signed.apk quick.apk $KEYALIAS  
  
  # Zipalign quick-signed.apk and name it quick-aligned.apk
  
  zipalign -v 4 quick-signed.apk quick-aligned.apk
  
  INTAPPNAME=${INTAPPNAME}${NEWVCODE}
  
  if [ ! -f  quick-aligned.apk ]; then 
    
    if [ $DEBUG = "true" ]; then 
     
      THETIMEISNOW=`date +%Y_%m_%d_%H_%M_%S`
      DEBUGDIR=$HOME/$INTAPPNAME-debug-$THETIMEISNOW
    
      cp -fr $WORKINGDIR $DEBUGDIR
      cp -fr $PROJECTDIR/builder-error.log $DEBUGDIR
      cp -fr $PROJECTDIR/x-quickapk.project $DEBUGDIR
         
    fi
    
    rm -fr $WORKINGDIR
    rm -fr /tmp/apktool_tmp
    rm -f *.apk
    
    exit 1
  
  fi
    
  # Moving to final APK
  
  OUTAPK=$HOME/${INTAPPNAME}.apk

  if [ -f $OUTAPK ]; then 
    
    NEWAPK=$OUTAPK
    
    while [ -f $NEWAPK ]; do
    
      let SUFFIX=$SUFFIX+1
      NEWAPK=$OUTAPK'_'$SUFFIX

    done
    OUTAPK=$NEWAPK
    
  fi  
     
  mv -f quick-aligned.apk $OUTAPK
    
  echo -n $OUTAPK > $PROJECTDIR/x-quickapk.txt

  # debug
  
  if [ $DEBUG = "true" ]; then 
   
    THETIMEISNOW=`date +%Y_%m_%d_%H_%M_%S`
    DEBUGDIR=$HOME/$INTAPPNAME-debug-$THETIMEISNOW
    
    cp -fr $WORKINGDIR $DEBUGDIR
    cp -fr $PROJECTDIR/builder-error.log $DEBUGDIR
    cp -fr $PROJECTDIR/x-quickapk.project $DEBUGDIR
    
  fi  
  
  rm -fr $WORKINGDIR
  rm -fr /tmp/apktool_tmp
  rm -f *.apk
  
}  

BuildAPK &> $PROJECTDIR/builder-error.log

exit 0

  